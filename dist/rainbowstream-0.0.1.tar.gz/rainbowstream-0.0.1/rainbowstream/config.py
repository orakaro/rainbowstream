# This is RainbowStream App info
CONSUMER_KEY = 'Xk1DGhR1FJa4xjg7GbdogzLJw'
CONSUMER_SECRET = 'SpHtDmbSGCSm55AAlIeb2PsD3kGEzxyo1325rJgrND5abeOh2T'

# Max Search record
SEARCH_MAX_RECORD = 5
# Default home tweet
HOME_TWEET_NUM = 5

# Stream Domain
USER_DOMAIN = 'userstream.twitter.com'
PUBLIC_DOMAIN = 'stream.twitter.com'
SITE_DOMAIN = 'sitestream.twitter.com'
# Actually called
DOMAIN = USER_DOMAIN

# Filter and Ignore list ex: ['@fat','@mdo']
ONLY_LIST = []
IGNORE_LIST = []
